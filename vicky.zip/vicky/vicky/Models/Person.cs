﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace vicky.Models
{
    public class Person
    {

        SqlConnection con = new SqlConnection();
        List<Person> PersonList = new List<Person>();
        public String Name { get; set; }
        public Int32 Age { get; set; }
 
        Person p = null;
        public List<Person> GetPerson()
        {

            con.ConnectionString = "Data Source=PC348873;Initial Catalog=InfraCost;Integrated Security=True";
           
             con.Open();
 
            using (con)
            {
               
            SqlCommand cmd = new SqlCommand("Select * from Person",con);
               
            SqlDataReader rd = cmd.ExecuteReader();
               
            while (rd.Read())
               
            {
                   
                    p = new Person();
                    p.Name =Convert.ToString(rd.GetSqlValue(0));
                   
                    p.Age = Convert.ToInt32(rd.GetInt32(1));
                    PersonList.Add(p);
               
            }
            }
            return PersonList;
        }
    }
}