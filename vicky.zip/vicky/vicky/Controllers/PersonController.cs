﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using vicky.Models;

namespace vicky.Controllers
{
    public class PersonController : Controller
    {
        //
        // GET: /Person/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetPerson()
        {
            Person p = new Person();
            List<Person> Li = new List<Person>();

            Li = p.GetPerson();
            ViewBag.details = Li;
          //  ViewData["Person"] = Li;
            return View();
        }

    }
}
